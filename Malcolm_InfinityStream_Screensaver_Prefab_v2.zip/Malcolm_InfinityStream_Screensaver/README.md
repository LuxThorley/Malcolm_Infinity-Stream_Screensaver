# Malcolm AI — Infinity Stream Screensaver (Windows 10)

This package builds a single Windows `.scr` screensaver that renders a shader-driven "cosmic intelligence field",
modulated by **real-time signal streams** and an optional **voice-responsive consciousness layer**.

## ✅ What’s updated in this version
- **Stream connection is handled by the native `.scr` host (C#)** using `HttpClient` (SSE) or `ClientWebSocket` (WS)
- Supports **Bearer token** auth from `config\config.json`
- The host forwards normalized signal values into WebView via `PostWebMessageAsJson`
- Web layer no longer needs CORS to reach the endpoint

> Voice-reactive mode uses Web Audio API and may prompt for microphone permission the first time.

---

## Quick start
1) Unzip somewhere (e.g. `C:\Temp\MalcolmInfinityStream`)
2) Edit `config\config.json`:
   - Set `signal.url` to your endpoint (example below)
   - Paste your token into `signal.bearer_token`
3) Right-click `scripts\install.ps1` → **Run with PowerShell (Admin)**

Then:
- Settings → Personalization → Lock screen → Screen saver settings → select **MalcolmInfinityStream**

---

## Configure Malcolm Infinity endpoint (example)
Edit: `config\config.json`

```json
"signal": {
  "mode": "sse",
  "url": "https://malcolmai.live/infinity/stream",
  "bearer_token": "PASTE_YOUR_TOKEN_HERE",
  "reconnect_ms": 1500,
  "smoothing": 0.88
}
```

### Expected message format
The host tries a few formats:
- JSON object: `{ "value": 0.42 }`
- JSON number: `0.42`
- SSE `data:` lines containing either of the above

If parsing fails, it keeps the last good value and retries.

---

## Build manually
```powershell
cd scripts
./build.ps1
```

Outputs:
- `dist\InfinityStreamSaver.scr`
- `dist\MalcolmInfinityStream\` (assets)

---

## Security note
**Do not hardcode tokens into source control.** Keep them only in your local `config.json`.
