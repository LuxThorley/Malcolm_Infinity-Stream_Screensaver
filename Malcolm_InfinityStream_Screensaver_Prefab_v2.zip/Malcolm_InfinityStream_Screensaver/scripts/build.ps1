param(
  [string]$Configuration = "Release"
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$proj = Join-Path $root "screensaver\InfinityStreamSaver.csproj"
$dist = Join-Path $root "dist"
$distApp = Join-Path $dist "MalcolmInfinityStream"
$distScr = Join-Path $dist "InfinityStreamSaver.scr"

Write-Host "== Malcolm Infinity Stream: build =="

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
  throw "dotnet SDK not found. Install .NET 6+ SDK from Microsoft then re-run."
}

if (Test-Path $dist) { Remove-Item $dist -Recurse -Force }
New-Item -ItemType Directory -Path $distApp | Out-Null

dotnet restore $proj
dotnet build $proj -c $Configuration -p:Platform=x64

$outDir = Join-Path $root "screensaver\bin\x64\$Configuration\net6.0-windows"
$exe = Join-Path $outDir "InfinityStreamSaver.exe"
if (-not (Test-Path $exe)) { throw "Build output not found: $exe" }

Copy-Item $exe $distScr -Force

Copy-Item (Join-Path $root "web") (Join-Path $distApp "web") -Recurse -Force
Copy-Item (Join-Path $root "config") (Join-Path $distApp "config") -Recurse -Force
Copy-Item (Join-Path $root "README.md") (Join-Path $distApp "README.md") -Force

Write-Host "Built:"
Write-Host " - $distScr"
Write-Host " - $distApp"
