param(
  [switch]$SetAsDefault
)

$ErrorActionPreference = "Stop"

function Require-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p = New-Object Security.Principal.WindowsPrincipal($id)
  if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Please run this script as Administrator."
  }
}

Require-Admin

$root = Split-Path -Parent $PSScriptRoot
Write-Host "== Malcolm Infinity Stream: install =="

& (Join-Path $PSScriptRoot "build.ps1") -Configuration Release

$dist = Join-Path $root "dist"
$scr = Join-Path $dist "InfinityStreamSaver.scr"
$app = Join-Path $dist "MalcolmInfinityStream"

if (-not (Test-Path $scr)) { throw "Missing built screensaver: $scr" }
if (-not (Test-Path $app)) { throw "Missing built assets: $app" }

$pf = ${env:ProgramFiles}
$installRoot = Join-Path $pf "MalcolmInfinityStream"
$systemScr = Join-Path $env:WINDIR "System32\MalcolmInfinityStream.scr"

if (Test-Path $installRoot) { Remove-Item $installRoot -Recurse -Force }
Copy-Item $app $installRoot -Recurse -Force

Copy-Item $scr $systemScr -Force

Write-Host "Installed to:"
Write-Host " - $installRoot"
Write-Host " - $systemScr"

if ($SetAsDefault) {
  $key = "HKCU:\Control Panel\Desktop"
  Set-ItemProperty $key ScreenSaveActive "1"
  Set-ItemProperty $key SCRNSAVE.EXE $systemScr
  Write-Host "Set as active screensaver for current user."
}

Write-Host ""
Write-Host "Next: Settings -> Personalization -> Lock screen -> Screen saver settings"
Write-Host "Select: MalcolmInfinityStream"
