param()

$ErrorActionPreference = "Stop"

function Require-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p = New-Object Security.Principal.WindowsPrincipal($id)
  if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Please run this script as Administrator."
  }
}

Require-Admin

$pf = ${env:ProgramFiles}
$installRoot = Join-Path $pf "MalcolmInfinityStream"
$systemScr = Join-Path $env:WINDIR "System32\MalcolmInfinityStream.scr"

if (Test-Path $installRoot) { Remove-Item $installRoot -Recurse -Force }
if (Test-Path $systemScr) { Remove-Item $systemScr -Force }

Write-Host "Uninstalled Malcolm Infinity Stream."
