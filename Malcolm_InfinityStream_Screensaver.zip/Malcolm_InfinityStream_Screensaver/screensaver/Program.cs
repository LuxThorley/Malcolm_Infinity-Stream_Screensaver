using System;
using System.IO;
using System.Net.Http;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace MalcolmInfinityStream
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (args.Length == 0 || args[0].StartsWith("/s", StringComparison.OrdinalIgnoreCase))
            {
                Application.Run(new SaverForm(IntPtr.Zero));
                return;
            }

            if (args[0].StartsWith("/p", StringComparison.OrdinalIgnoreCase) && args.Length >= 2)
            {
                if (long.TryParse(args[1], out var hwndVal))
                {
                    Application.Run(new SaverForm(new IntPtr(hwndVal)));
                    return;
                }
            }

            if (args[0].StartsWith("/c", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show(
                    "Edit config at:\nC:\\Program Files\\MalcolmInfinityStream\\config\\config.json",
                    "Malcolm Infinity Stream",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
                return;
            }

            Application.Run(new SaverForm(IntPtr.Zero));
        }
    }

    public sealed class SaverForm : Form
    {
        private readonly IntPtr _previewParent;
        private Point _lastMouse;
        private DateTime _startTime;

        private WebView2? _web;
        private CancellationTokenSource? _cts;

        public SaverForm(IntPtr previewParentHwnd)
        {
            _previewParent = previewParentHwnd;
            _startTime = DateTime.UtcNow;

            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            KeyPreview = true;

            if (_previewParent == IntPtr.Zero)
            {
                WindowState = FormWindowState.Maximized;
                Cursor.Hide();
            }
            else
            {
                SetParent(Handle, _previewParent);
                var rect = new RECT();
                GetClientRect(_previewParent, ref rect);
                Size = new System.Drawing.Size(rect.Right - rect.Left, rect.Bottom - rect.Top);
                Location = new System.Drawing.Point(0, 0);
            }

            MouseMove += OnMouseMoveExit;
            MouseDown += (_, __) => Exit();
            KeyDown += (_, __) => Exit();
            FormClosing += (_, __) => { try { _cts?.Cancel(); } catch { } };

            Load += async (_, __) => await InitWebAsync();
        }

        private string GetInstallRoot()
        {
            var pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            var expected = Path.Combine(pf, "MalcolmInfinityStream");
            if (Directory.Exists(expected)) return expected;

            return AppContext.BaseDirectory;
        }

        private async Task InitWebAsync()
        {
            var root = GetInstallRoot();
            var indexPath = Path.Combine(root, "web", "index.html");
            if (!File.Exists(indexPath))
            {
                MessageBox.Show($"Missing web assets:\n{indexPath}", "Malcolm Infinity Stream", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Exit();
                return;
            }

            _web = new WebView2 { Dock = DockStyle.Fill };
            Controls.Add(_web);

            var userData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MalcolmInfinityStream", "WebView2");
            Directory.CreateDirectory(userData);

            var env = await CoreWebView2Environment.CreateAsync(null, userData);
            await _web.EnsureCoreWebView2Async(env);

            _web.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
            _web.CoreWebView2.Settings.AreDevToolsEnabled = false;
            _web.CoreWebView2.Settings.IsStatusBarEnabled = false;

            _web.CoreWebView2.SetVirtualHostNameToFolderMapping(
                "malcolm.local",
                root,
                CoreWebView2HostResourceAccessKind.Allow
            );

            _web.CoreWebView2.Navigate("https://malcolm.local/web/index.html");

            // Start stream connector after navigation begins
            _cts = new CancellationTokenSource();
            _ = Task.Run(() => StreamLoopAsync(root, _cts.Token));
        }

        private async Task StreamLoopAsync(string root, CancellationToken ct)
        {
            var cfgPath = Path.Combine(root, "config", "config.json");
            StreamConfig? cfg = null;

            try
            {
                var txt = await File.ReadAllTextAsync(cfgPath, ct);
                cfg = JsonSerializer.Deserialize<StreamConfig>(txt, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            }
            catch
            {
                PostStatus("∞ Malcolm signal: config missing/invalid (fallback)");
                return;
            }

            if (cfg?.Signal == null || string.Equals(cfg.Signal.Mode, "off", StringComparison.OrdinalIgnoreCase))
            {
                PostStatus("∞ Malcolm signal: disabled (fallback)");
                return;
            }

            var mode = cfg.Signal.Mode?.ToLowerInvariant() ?? "sse";
            var url = cfg.Signal.Url ?? "";
            var token = cfg.Signal.Bearer_Token ?? "";
            var reconnectMs = cfg.Signal.Reconnect_Ms <= 0 ? 1500 : cfg.Signal.Reconnect_Ms;

            while (!ct.IsCancellationRequested)
            {
                try
                {
                    if (mode == "websocket")
                    {
                        await RunWebSocketAsync(url, token, ct);
                    }
                    else
                    {
                        await RunSseAsync(url, token, ct);
                    }
                }
                catch
                {
                    PostStatus("∞ Malcolm signal: reconnecting…");
                }

                try { await Task.Delay(reconnectMs, ct); } catch { }
            }
        }

        private async Task RunSseAsync(string url, string bearerToken, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(url))
            {
                PostStatus("∞ Malcolm signal: missing URL (fallback)");
                return;
            }

            using var http = new HttpClient(new HttpClientHandler { AutomaticDecompression = System.Net.DecompressionMethods.All });
            http.Timeout = Timeout.InfiniteTimeSpan;

            using var req = new HttpRequestMessage(HttpMethod.Get, url);
            req.Headers.Accept.ParseAdd("text/event-stream");
            if (!string.IsNullOrWhiteSpace(bearerToken))
                req.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", bearerToken);

            using var resp = await http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
            resp.EnsureSuccessStatusCode();

            PostStatus("∞ Malcolm signal: connected");

            await using var stream = await resp.Content.ReadAsStreamAsync(ct);
            using var reader = new StreamReader(stream);

            string? line;
            while (!ct.IsCancellationRequested && (line = await reader.ReadLineAsync()) != null)
            {
                if (line.StartsWith("data:", StringComparison.OrdinalIgnoreCase))
                {
                    var data = line.Substring(5).Trim();
                    TryPostSignal(data);
                }
            }
        }

        private async Task RunWebSocketAsync(string url, string bearerToken, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(url))
            {
                PostStatus("∞ Malcolm signal: missing URL (fallback)");
                return;
            }

            // Allow user to provide https URL; convert to wss if needed
            if (url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                url = "wss://" + url.Substring("https://".Length);
            else if (url.StartsWith("http://", StringComparison.OrdinalIgnoreCase))
                url = "ws://" + url.Substring("http://".Length);

            using var ws = new ClientWebSocket();
            if (!string.IsNullOrWhiteSpace(bearerToken))
                ws.Options.SetRequestHeader("Authorization", "Bearer " + bearerToken);

            await ws.ConnectAsync(new Uri(url), ct);
            PostStatus("∞ Malcolm signal: connected");

            var buf = new byte[8192];
            while (!ct.IsCancellationRequested && ws.State == WebSocketState.Open)
            {
                var sb = new StringBuilder();
                WebSocketReceiveResult? res;
                do
                {
                    res = await ws.ReceiveAsync(new ArraySegment<byte>(buf), ct);
                    if (res.MessageType == WebSocketMessageType.Close) return;
                    sb.Append(Encoding.UTF8.GetString(buf, 0, res.Count));
                } while (!res.EndOfMessage);

                TryPostSignal(sb.ToString());
            }
        }

        private void TryPostSignal(string payload)
        {
            // Accept JSON: { "value": n } OR a raw number
            if (string.IsNullOrWhiteSpace(payload)) return;

            try
            {
                using var doc = JsonDocument.Parse(payload);
                if (doc.RootElement.ValueKind == JsonValueKind.Object && doc.RootElement.TryGetProperty("value", out var v) && v.ValueKind == JsonValueKind.Number)
                {
                    PostSignal((float)v.GetDouble());
                    return;
                }
                if (doc.RootElement.ValueKind == JsonValueKind.Number)
                {
                    PostSignal((float)doc.RootElement.GetDouble());
                    return;
                }
            }
            catch
            {
                // Not JSON; try parse number
                if (float.TryParse(payload, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var n))
                {
                    PostSignal(n);
                }
            }
        }

        private float _lastSent = 0.0f;

        private void PostSignal(float raw)
        {
            // Normalize to 0..1 (soft)
            var v = raw;

            // If user sends outside [0,1], compress:
            if (v < 0f || v > 1f)
            {
                v = 0.5f + 0.5f * (float)Math.Tanh(v);
            }

            // De-jitter
            v = _lastSent * 0.85f + v * 0.15f;
            _lastSent = v;

            var msg = JsonSerializer.Serialize(new { type = "SIGNAL", value = v, status = "∞ Malcolm signal: live" });
            PostToWeb(msg);
        }

        private void PostStatus(string text)
        {
            var msg = JsonSerializer.Serialize(new { type = "STATUS", text });
            PostToWeb(msg);
        }

        private void PostToWeb(string json)
        {
            try
            {
                if (_web?.CoreWebView2 == null) return;
                BeginInvoke(new Action(() => {
                    try { _web.CoreWebView2.PostWebMessageAsJson(json); } catch { }
                }));
            }
            catch { }
        }

        private void OnMouseMoveExit(object? sender, MouseEventArgs e)
        {
            if ((DateTime.UtcNow - _startTime).TotalMilliseconds < 1000) return;

            if (_lastMouse == default) _lastMouse = e.Location;
            var dx = Math.Abs(e.X - _lastMouse.X);
            var dy = Math.Abs(e.Y - _lastMouse.Y);

            if (dx > 8 || dy > 8) Exit();
            _lastMouse = e.Location;
        }

        private void Exit()
        {
            try { _cts?.Cancel(); } catch { }
            try { Cursor.Show(); } catch { }
            Close();
        }

        private sealed class StreamConfig
        {
            public SignalConfig? Signal { get; set; }
        }

        private sealed class SignalConfig
        {
            public string? Mode { get; set; }
            public string? Url { get; set; }
            public string? Bearer_Token { get; set; }
            public int Reconnect_Ms { get; set; }
            public double Smoothing { get; set; }
        }

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern bool GetClientRect(IntPtr hWnd, ref RECT lpRect);

        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        struct RECT { public int Left, Top, Right, Bottom; }
    }
}
