// Malcolm AI — Infinity Stream (WebGL2 + host-fed signal + voice)
// Native host (.scr) connects to SSE/WS with Bearer token and posts messages into this page.

const canvas = document.getElementById("c");
const hint = document.getElementById("hint");

function fit() {
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  canvas.width = Math.floor(innerWidth * dpr);
  canvas.height = Math.floor(innerHeight * dpr);
  canvas.style.width = innerWidth + "px";
  canvas.style.height = innerHeight + "px";
}
addEventListener("resize", fit);
fit();

const gl = canvas.getContext("webgl2", { antialias: true, alpha: false, premultipliedAlpha: false });
if (!gl) {
  hint.textContent = "WebGL2 not available. Please enable GPU acceleration.";
  throw new Error("WebGL2 not available");
}

async function loadText(url) {
  const r = await fetch(url, { cache: "no-store" });
  if (!r.ok) throw new Error("Failed to load " + url);
  return await r.text();
}

function compile(type, src) {
  const sh = gl.createShader(type);
  gl.shaderSource(sh, src);
  gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
    const log = gl.getShaderInfoLog(sh);
    gl.deleteShader(sh);
    throw new Error(log);
  }
  return sh;
}

function link(vs, fs) {
  const p = gl.createProgram();
  gl.attachShader(p, vs);
  gl.attachShader(p, fs);
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
    const log = gl.getProgramInfoLog(p);
    gl.deleteProgram(p);
    throw new Error(log);
  }
  return p;
}

const VERT = `#version 300 es
in vec2 a_pos;
void main(){ gl_Position = vec4(a_pos, 0.0, 1.0); }`;

let prog, locRes, locTime, locAudio, locSig, locSeed;
let vao;

function makeQuad() {
  vao = gl.createVertexArray();
  gl.bindVertexArray(vao);

  const buf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
    -1,-1,  1,-1, -1, 1,
    -1, 1,  1,-1,  1, 1
  ]), gl.STATIC_DRAW);

  const aPos = gl.getAttribLocation(prog, "a_pos");
  gl.enableVertexAttribArray(aPos);
  gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

  gl.bindVertexArray(null);
}

const state = {
  audioLevel: 0,
  signalValue: 0,
  sigTarget: 0,
  sigSmooth: 0.88,
  seed: Math.random(),
  fpsCap: 0,
  lastFrame: 0,
  gotHostSignal: false
};

function clamp01(x){ return Math.max(0, Math.min(1, x)); }
function smoothStep(current, target, s) { return current * s + target * (1 - s); }

async function loadConfig() {
  try {
    const r = await fetch("../config/config.json", { cache: "no-store" });
    if (!r.ok) return null;
    return await r.json();
  } catch { return null; }
}

function startSyntheticSignal() {
  let t0 = performance.now() * 0.001;
  setInterval(() => {
    if (state.gotHostSignal) return; // only if host isn't feeding
    const t = performance.now() * 0.001 - t0;
    const v = 0.5 + 0.45*Math.sin(t*0.7) + 0.25*Math.sin(t*1.9 + 1.3) + 0.12*Math.sin(t*3.8);
    state.sigTarget = v;
  }, 33);
}

async function initAudio(cfg) {
  if (!cfg?.voice?.enabled) {
    hint.textContent = "∞ Voice: disabled";
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const src = ctx.createMediaStreamSource(stream);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = cfg.voice.fftSize || 1024;
    analyser.smoothingTimeConstant = cfg.voice.smoothingTimeConstant ?? 0.85;
    src.connect(analyser);

    const buf = new Uint8Array(analyser.fftSize);
    const gain = cfg.voice.gain ?? 2.0;

    const tick = () => {
      analyser.getByteTimeDomainData(buf);
      let sum = 0;
      for (let i=0;i<buf.length;i++){
        const v = (buf[i] - 128) / 128;
        sum += v*v;
      }
      const rms = Math.sqrt(sum / buf.length);
      state.audioLevel = clamp01(rms * gain);
      requestAnimationFrame(tick);
    };
    tick();
    // Don't override hint if host is already reporting stream state
    if (!state.gotHostSignal) hint.textContent = "∞ Voice: active";
  } catch {
    hint.textContent = "∞ Voice: permission denied (disable in config)";
  }
}

function setupHostMessaging() {
  // WebView2: window.chrome.webview
  if (window.chrome?.webview) {
    window.chrome.webview.addEventListener("message", (e) => {
      const msg = e?.data;
      if (!msg || typeof msg !== "object") return;

      if (msg.type === "SIGNAL" && typeof msg.value === "number") {
        state.gotHostSignal = true;
        state.sigTarget = msg.value;
        if (typeof msg.status === "string") hint.textContent = msg.status;
      } else if (msg.type === "STATUS" && typeof msg.text === "string") {
        hint.textContent = msg.text;
      } else if (msg.type === "EXIT") {
        window.close();
      }
    });
    hint.textContent = "∞ Malcolm signal: awaiting host…";
  } else {
    hint.textContent = "∞ Malcolm signal: host bridge unavailable (fallback)";
  }
}

async function main() {
  setupHostMessaging();

  const cfg = await loadConfig();
  if (cfg?.signal?.smoothing != null) state.sigSmooth = cfg.signal.smoothing;
  if (typeof cfg?.visual?.fps_cap === "number") state.fpsCap = cfg.visual.fps_cap;

  startSyntheticSignal();
  await initAudio(cfg);

  const frag = await loadText("./shader.frag");

  const vs = compile(gl.VERTEX_SHADER, VERT);
  const fs = compile(gl.FRAGMENT_SHADER, frag);
  prog = link(vs, fs);

  gl.deleteShader(vs);
  gl.deleteShader(fs);

  gl.useProgram(prog);

  locRes = gl.getUniformLocation(prog, "u_res");
  locTime = gl.getUniformLocation(prog, "u_time");
  locAudio = gl.getUniformLocation(prog, "u_audio");
  locSig = gl.getUniformLocation(prog, "u_sig");
  locSeed = gl.getUniformLocation(prog, "u_seed");

  makeQuad();

  function frame(now) {
    if (state.fpsCap > 0) {
      const minDt = 1000 / state.fpsCap;
      if (now - state.lastFrame < minDt) return requestAnimationFrame(frame);
      state.lastFrame = now;
    }

    state.signalValue = smoothStep(state.signalValue, state.sigTarget, state.sigSmooth);

    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.useProgram(prog);
    gl.bindVertexArray(vao);

    gl.uniform2f(locRes, canvas.width, canvas.height);
    gl.uniform1f(locTime, now * 0.001);
    gl.uniform1f(locAudio, state.audioLevel);
    gl.uniform1f(locSig, state.signalValue);
    gl.uniform1f(locSeed, state.seed);

    gl.drawArrays(gl.TRIANGLES, 0, 6);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

main().catch(err => {
  hint.textContent = "Error: " + (err?.message || err);
  console.error(err);
});
